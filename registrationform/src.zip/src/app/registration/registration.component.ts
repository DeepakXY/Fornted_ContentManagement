import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User1 } from '../model/Userdata';
import { RegistrationformService } from '../services/registrationform.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  constructor(private studentformService:RegistrationformService,private _router :Router) { }
  UserObj=new User1()
fun1(){
  console.log(this.UserObj.username)
  this.studentformService.stordata(this.UserObj).subscribe({
    
    next: () =>{alert("Data Added"),
    this._router.navigate(['/login']) 
  },
    
  error(err){alert("error"+err)},
  complete(){alert("comleted")}}
  
  )
}
  

  ngOnInit(): void {
  }

}
