import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User1 } from '../model/Userdata';
@Injectable({
  providedIn: 'root'
})
export class RegistrationformService {

  constructor(private _http : HttpClient) { }
  public loginUserFormRemote(userdata :User1):Observable<any> {
    return this._http.post<any>("http://localhost:8082/user/v1/login",userdata);
    console.log(userdata)
  }
  
  
  stordata(data1:User1){
    console.log(data1)
return this._http.post("http://localhost:8082/user/v1/register",data1)
  }
}
