export class User1{
    
  useremail:string
  passwd:string
  username:string

 
  constructor(){
    
    this.useremail=''
    this.passwd=''
  this.username=''

    
   
  }

}